const test = require('node:test');
const assert = require('node:assert');
const server = require('../server');

let base;
test.before(() => new Promise((resolve) => {
  server.listen(0, () => { base = `http://localhost:${server.address().port}`; resolve(); });
}));
test.after(() => server.close());

test('GET / returns greeting', async () => {
  const r = await fetch(base + '/');
  assert.strictEqual(r.status, 200);
  assert.match((await r.json()).message, /Docker/);
});

test('GET /health returns ok', async () => {
  const r = await fetch(base + '/health');
  assert.strictEqual((await r.json()).status, 'ok');
});

test('unknown route returns 404', async () => {
  const r = await fetch(base + '/nope');
  assert.strictEqual(r.status, 404);
});
