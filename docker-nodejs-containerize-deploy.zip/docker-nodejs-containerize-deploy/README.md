# Containerize and Deploy: Node.js with Docker

Assignment Q30 (Industry SDLC_PBL), Woxsen University, School of Technology
Name: Devana Swathi Reddy | Roll No: 24WU0101114 | CSE - Rhinos

A small Node.js HTTP service containerized with Docker. The repo compares a naive
image (`Dockerfile.before`) with an optimized multi-stage image (`Dockerfile`).

## Endpoints
| Route | Purpose |
|---|---|
| `/` | Greeting and version |
| `/health` | Health check used by Docker HEALTHCHECK |
| `/info` | Node version, hostname (container ID), user |

## Run locally (without Docker)
    npm test
    npm start

## Build and run with Docker
    # BEFORE (baseline)
    docker build -f Dockerfile.before -t node-app:before .
    # AFTER (optimized)
    docker build -t node-app:after .

    docker images node-app
    docker run -d --name web -p 3000:3000 node-app:after
    curl http://localhost:3000/health
    docker ps          # STATUS shows (healthy)
    docker logs web
    docker stop web && docker rm web

## Docker Compose
    docker compose up -d --build
    docker compose down

## Publish and deploy
    docker login
    docker tag node-app:after <dockerhub-user>/docker-nodejs-containerize-deploy:1.0.0
    docker push <dockerhub-user>/docker-nodejs-containerize-deploy:1.0.0
    docker run -d -p 3000:3000 <dockerhub-user>/docker-nodejs-containerize-deploy:1.0.0

## Results
Fill in your measured values (image size, build time, layers) here.
