// Simple HTTP service used for the Docker containerize-and-deploy assignment
const http = require('http');
const os = require('os');

const PORT = process.env.PORT || 3000;
const APP_VERSION = process.env.APP_VERSION || '1.0.0';
const startedAt = Date.now();

function send(res, code, body) {
  res.writeHead(code, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(body, null, 2));
}

const server = http.createServer((req, res) => {
  if (req.url === '/') {
    return send(res, 200, { message: 'Hello from a Docker container', version: APP_VERSION });
  }
  if (req.url === '/health') {
    return send(res, 200, { status: 'ok', uptimeSeconds: Math.round((Date.now() - startedAt) / 1000) });
  }
  if (req.url === '/info') {
    return send(res, 200, {
      version: APP_VERSION,
      node: process.version,
      hostname: os.hostname(),       // equals the container ID inside Docker
      platform: process.platform,
      env: process.env.NODE_ENV || 'development',
      user: os.userInfo().username,  // shows non-root user in the optimized image
    });
  }
  send(res, 404, { error: 'Not found' });
});

if (require.main === module) {
  server.listen(PORT, '0.0.0.0', () => console.log(`Server listening on port ${PORT}`));

  // Graceful shutdown so "docker stop" exits quickly and cleanly
  const shutdown = (signal) => {
    console.log(`${signal} received, shutting down`);
    server.close(() => process.exit(0));
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

module.exports = server;
